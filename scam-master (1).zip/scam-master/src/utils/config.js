export const SERVER_URL = "https://redirection1992.herokuapp.com/";
